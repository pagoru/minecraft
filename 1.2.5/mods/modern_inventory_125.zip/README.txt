Modern Inventory 1.0 - Minecraft 1.2.5
Author: pagoru

Modern (1.8+) inventory controls for every container screen: player
inventory, chests, crafting table, furnace, dispenser, brewing stand...

  Left-drag a held stack over slots    split it evenly (white highlight)
  Right-drag a held stack over slots   place one item in each slot
  Double-click a stack                 gather matching items onto the cursor
  Shift + double-click                 move all matching items across
  1-9 over a slot                      swap it with that hotbar slot
  Q over a slot                        drop one item
  Ctrl+Q over a slot                   drop the whole stack
  Middle-click (creative)              pick up a full stack

The creative inventory screen (E in creative) keeps its vanilla controls.
No vanilla classes are edited.

Single player. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put modern_inventory_125.zip in .minecraft/mods/.
