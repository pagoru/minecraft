Rain & Thunder 1.0 - Minecraft 1.2.5
Author: pagoru
Created: 13/7/2013

- Fixes the missing rain sound: adds rain and thunder sounds
  (ambient.weather.rain / ambient.weather.thunder) bundled in the mod.
- Permanent thunderstorm: in singleplayer worlds it always rains
  (snows in cold biomes, nothing in deserts) and lightning keeps striking.

Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
