Rain & Thunder 1.1 - Minecraft 1.2.5
Author: pagoru
Created: 13/7/2013

- Fixes the missing rain sound: adds rain and thunder sounds
  (ambient.weather.rain / ambient.weather.thunder) bundled in the mod.
- Permanent thunderstorm: in singleplayer worlds it always rains
  (snows in cold biomes, nothing in deserts) and lightning keeps striking.
- Random weather events on top of the storm (singleplayer):
  * Fog: the view distance shrinks for a few minutes, then comes back.
  * Extreme storm: faster-looking rain, hail (cosmetic, no damage),
    louder rain, loud thunder and a light wind that pushes mobs and the
    player sideways (no damage).
  * Sun break: only in the daytime the storm stops for a few minutes,
    then resumes (also ends at dusk).
  Chances and durations are constants at the top of mod_RainThunder.java.

Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
