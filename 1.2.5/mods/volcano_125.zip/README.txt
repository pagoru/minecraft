Volcano 1.0 - Minecraft 1.2.5
Author: pagoru

V: raise a huge volcano where you are looking (up to 80 blocks away; if you
look at the sky it is built ahead of you, never on top of you).
Cone about 34 blocks tall and 70 wide of stone, cobblestone, netherrack and
obsidian, with a crater full of lava.

Timeline:
1. A few seconds of rumbling.
2. The cone grows layer by layer (about 15 seconds). Random mini earthquakes
   shake the screen, and holes open in the ground around the volcano (up to
   12) that spout lava, flames and smoke.
3. Big eruption (about 100 seconds): explosion, rocks and lava bombs flying
   out of the crater (rocks can explode or hurt if they hit you, lava bombs
   leave lava and fire), lava fountains, smoke plume, lava streams running
   down the sides.
4. About 60 seconds of aftershocks while it calms down.
Everything is spread over time to avoid lag.
Key can be changed in Options > Controls ("Volcano").
Does nothing in multiplayer or while a menu/chat is open. Particles are
skipped if Particles is set to Minimal.

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put volcano_125.zip in .minecraft/mods/.
