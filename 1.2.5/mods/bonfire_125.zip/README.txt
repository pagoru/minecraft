Campfire 1.1 - Minecraft 1.2.5
Author: pagoru

CAMPFIRE (id 200)
  Craft:  _S_ / SCS / LLL   (S = stick, C = coal or charcoal, L = log)
  Right-click with a log to put it in (max 3). Over time (random, ~1 min per try)
  logs turn into charcoal (max 3 inside). Right-click with anything else to take the charcoal.
  Low 3D model like the modern campfire (crossed logs, ember bed, flames while burning).
  Breaking it gives back whatever is inside.

CHARCOAL
  Vanilla charcoal: smelt a log in a furnace (or let the campfire do it).

CHARCOAL BLOCK (id 201)
  Craft: 9 charcoal (3x3). One block back -> 9 charcoal.

DIAMOND PRESS
  Put a charcoal block and place 4 pistons around it (the 4 horizontal sides), every piston
  facing the block and just touching it (retracted). Power all 4 pistons at the same time with
  a redstone clock. Each time all 4 get powered counts as 1 compression (the block can't be
  pushed, so the pistons don't move). After 7 compressions the block disappears and drops a diamond (50%)
  or 3-9 coal (50%).
  Change the number in BlockCharcoal.COMPRESSIONS (max 7).

Single player. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put bonfire_125.zip in .minecraft/mods/.
