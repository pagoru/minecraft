Heart Container 1.0 - Minecraft 1.2.5
Author: pagoru

Terraria-style life crystal. Right-click a Heart Container to get one extra
heart (+2 max health) forever, up to 10 extra hearts (20 hearts in total).
The extra hearts show as a second row above your normal hearts and refill
with food like normal hearts (when you're full they regenerate too).
They are kept when you die (you respawn with all your hearts full) and are
saved per world in <world folder>/heart_container.txt.

Getting it:
- Crafting (stack of 1):   R . R
                           R D R      R = redstone, D = diamond
                           . R .
- Rare loot in dungeon chests.
- Creative inventory (at the end of the list).

Single player. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put heart_container_125.zip in .minecraft/mods/.
Uses item ID 2301.
