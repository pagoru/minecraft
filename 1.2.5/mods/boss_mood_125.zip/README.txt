Boss Mood 1.0 - Minecraft 1.2.5
Author: pagoru
Created: 13/7/2013

- Boss music: plays on loop while you fight the Ender Dragon (alive, within
  150 blocks). Stops when the dragon dies, you die or you leave.
- Elden Ring style death screen: dark fade, big red "YOU DIED", buttons appear
  after ~3 seconds.

Boss music: Dark Souls III - Vordt of the Boreal Valley (bundled boss.ogg).
  To use another track, put your own Ogg Vorbis file at
  .minecraft/mods/boss_mood/boss.ogg (it wins over the bundled one).

Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
