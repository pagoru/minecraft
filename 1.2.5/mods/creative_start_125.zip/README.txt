Creative Start 1.0 - Minecraft 1.2.5
Author: pagoru

A newly created single player world starts in creative mode with an empty
inventory. It only happens once, the first time the world is loaded: a marker
file creative_start.dat is written in the world's folder. Worlds that already
exist are never changed, and afterwards you can switch mode normally (F4 with
Gamemode Toggle). Hardcore worlds are skipped.

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
