Wait Disc 1.0 - Minecraft 1.2.5
Author: pagoru
Created: 13/7/2013

Adds a music disc that plays "wait".
How to get it: when a skeleton kills a creeper, the creeper drops this disc.
Recipe (for testing): 4 snow blocks (16 snowballs) in a 2x2.

Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
