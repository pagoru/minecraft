Death Chest 1.0 - Minecraft 1.2.5
Author: pagoru

When you die nothing drops. A Death Chest appears where you died and holds
your inventory, armor and experience. The chest cannot be broken. Right-click
it and everything returns to you (same slots when free), then the chest
disappears. It is saved with the world, so it survives reloads.

Single player. Block ID 202 (was 200, clashed with bonfire). Note: creative mode can still break any block.

Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
