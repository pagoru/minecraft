Keep Inventory 1.4 - Minecraft 1.2.5
Author: pagoru

In creative, 1.2.5 refills empty hotbar slots with stone, brick, dirt, etc.
every time you load a world. This mod undoes that.

The mod saves NOTHING by itself. The inventory is the one the game saved in
the world's own level.dat (Player/Inventory), so it is part of the world and
of any backup: restoring a backup gives exactly the inventory it had. When a
world loads, the mod puts that saved inventory back over the creative refill.
It also survives changing dimension. The old keep_inventory.dat is no longer
used (you can delete it).
Single player, every gamemode.

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
