Keep Inventory 1.1 - Minecraft 1.2.5
Author: pagoru

In creative, 1.2.5 fills the hotbar with stone, brick, dirt, etc. and sets
stacks to 1 every time you load a world. This mod keeps the inventory of each
world separately: it is saved to keep_inventory.dat in the world's own folder
(every second) and loaded when you open that world. Worlds never share an
inventory. It also survives changing dimension.
Single player, every gamemode: the inventory is never swapped on a gamemode change.

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
