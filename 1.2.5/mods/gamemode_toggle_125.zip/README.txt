Gamemode Toggle 1.0 - Minecraft 1.2.5
Author: pagoru

Press F4 in single player to switch between survival and creative.
The world is saved with the new mode,
so it shows it in the world list and reopens in it.
The key can be changed in Options > Controls ("Toggle gamemode").
Does nothing in multiplayer or hardcore worlds.

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put gamemode_toggle_125.zip in .minecraft/mods/.
