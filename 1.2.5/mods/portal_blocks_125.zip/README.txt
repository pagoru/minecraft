Portal Blocks 1.0 - Minecraft 1.2.5
Author: pagoru

Adds to the creative inventory (after the last block):
- End portal frame
- End portal (the black/starry portal surface)
- Nether portal

To build an end portal: place 12 frames in a 5x5 ring (3 per side, corners
empty) and right-click each with an eye of ender, or just place end portal
blocks directly. Nether portal blocks vanish by themselves if they are not
inside an obsidian frame (vanilla behaviour); light a 4x5 obsidian frame
with flint and steel instead.
