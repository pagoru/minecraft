Earthquake 1.0 - Minecraft 1.2.5
Author: pagoru

K: start an earthquake. The screen shakes with a rumble for about 4 seconds,
then a ravine opens where you were looking (up to 64 blocks away; if you look
at the sky, in front of you).
The ravine is 3-5 blocks wide and 30-60 long, in your view direction, with
irregular edges, down to near bedrock (lava at the bottom). It opens slice by
slice over a few seconds.
Key can be changed in Options > Controls ("Earthquake").
Does nothing in multiplayer or while a menu/chat is open.

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put earthquake_125.zip in .minecraft/mods/.
