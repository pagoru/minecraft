Earthquake 2.0 - Minecraft 1.2.5
Author: pagoru

K: start an earthquake. A blast, then about 9 seconds of violent shaking with
rumbling and jolts, then a huge ravine tears open where you were looking (up to
64 blocks away; if you look at the sky, in front of you), with explosions,
debris and smoke.
The ravine is 5-9 blocks wide and 60-110 long, in your view direction, with
irregular edges, down to near bedrock (lava at the bottom).
Also: 6-9 mini ravines crossing it (with water pools), several caves opening off
its walls, and waterfalls and lavafalls pouring into it.
It opens slice by slice over a few seconds.
Key can be changed in Options > Controls ("Earthquake").
Does nothing in multiplayer or while a menu/chat is open.

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put earthquake_125.zip in .minecraft/mods/.
