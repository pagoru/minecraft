Immortal 1.0 - Minecraft 1.2.5
Author: pagoru
Created: 13/7/2013

You cannot die. Any damage (mobs, fall, lava, fire, drowning, void, explosions,
starvation, the H key of Health Keys) only lowers your health down to half a
heart (1 HP), never below. Healing works normally.
Drowning is prevented (air never runs out) and falling into the void teleports
you back to safe ground (or the spawn point).

Dramatic effects (client side):
- Heartbeat that gets faster and louder as health drops (from 3 hearts).
- Pulsing red vignette and faint red tint, stronger at half a heart.
- Slow camera sway and a small kick on every beat at half a heart.
- Slightly slower walking at half a heart.
- Near-death moment every time health first falls to half a heart: white/red
  flash, thunder and explosion sounds, blood-red dust and smoke, camera kick.

Values are constants at the top of mod_Immortal.java.
Works with Health Keys (H cannot kill you). Singleplayer only.

Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put immortal_125.zip in .minecraft/mods/.
