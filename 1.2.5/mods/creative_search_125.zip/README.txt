Creative Search 1.0 - Minecraft 1.2.5
Author: pagoru

Adds a search box to the creative inventory (top right of the panel).
- Type to filter all items by name (vanilla and modded). Several words: all must match.
- A number matches the item ID.
- Right-click the box to clear it. Enter leaves the box (E closes the screen again); click the box to type again.

The vanilla creative screen is replaced by a subclass (GuiCreativeSearch), so mods that
check "instanceof GuiContainerCreative" (dragon_egg, mini_dragon, portal_blocks, heart_container) keep working.

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
