Custom Skin 1.0 - Minecraft 1.2.5
Author: pagoru

Replaces the default Steve skin of your own player with skin.png bundled in
this mod. The old skin servers are dead, so the skin is loaded locally.
Client only: other players still see Steve (and you see them as Steve).

Change the skin: open customskin_125.zip (in .minecraft/mods/) and replace skin.png
with your own 64x32 skin PNG, same name. No rebuild needed.

Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
