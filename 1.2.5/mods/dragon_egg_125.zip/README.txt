Dragon Egg 1.0 - Minecraft 1.2.5
Author: pagoru

Adds the vanilla dragon egg to the creative inventory (after the last block).
Recipe (fallback): 8 obsidian around 1 eye of ender.

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
