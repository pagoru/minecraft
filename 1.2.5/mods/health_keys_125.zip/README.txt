Health Keys 1.0 - Minecraft 1.2.5
Author: pagoru

H: remove one heart (2 HP). At 1 heart or less it kills you.
J: add one heart (2 HP), up to your max health.
Keys can be changed in Options > Controls ("Remove health" / "Add health").
Does nothing in multiplayer or while a menu/chat is open.

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put health_keys_125.zip in .minecraft/mods/.
