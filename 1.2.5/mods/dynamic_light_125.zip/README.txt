Dynamic Light 1.0 - Minecraft 1.2.5
Author: pagoru

Holding a light item lights the area around you as you move:
torch, redstone torch (dim), glowstone, glowstone dust, jack o'lantern,
lava bucket, fire charge. Dropped light items on the ground glow too.

Uses two invisible light-only blocks (IDs 250 and 251). They are placed in
the air block at your position and removed when you move; leftovers remove
themselves. Change the IDs at the top of mod_DynamicLight.java if they clash.
Doesn't light up while underwater (needs an air block).
Single player only. Many moving lights can cost some FPS.

Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put dynamic_light_125.zip in .minecraft/mods/.
