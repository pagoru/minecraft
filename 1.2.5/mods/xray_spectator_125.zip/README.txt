Xray Spectator 1.0 - Minecraft 1.2.5
Author: pagoru

Press F6 in single player to toggle:
- Xray: stone, grass, dirt, cobblestone, sand, gravel, sandstone and
  netherrack become invisible, so caves, ores, lava and water show through.
  The screen is also set to full brightness (gamma 100%).
- Spectator: fly through blocks (noclip), no damage, mobs ignore you.
  Space = up, Shift = down.
Press F6 again to go back to normal. If you are inside a block when you turn it
off, you are moved up until free.
The key can be changed in Options > Controls ("Toggle xray spectator").

Does nothing in multiplayer. The state resets on world change or respawn.
Tip: unhidden blocks (ores, obsidian...) can still gently push you while flying.

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put xray_spectator_125.zip in .minecraft/mods/.
