Big Creeper 1.0 - Minecraft 1.2.5
Author: pagoru

Creeper explosions are bigger:
  - normal creeper: power 6 (vanilla 3)
  - charged creeper: power 10 (vanilla 6)
Change CREEPER_POWER / CHARGED_CREEPER_POWER at the top of
mod_BigCreeper.java to tune them.

Singleplayer only (in multiplayer the server controls explosions).

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put big_creeper_125.zip in .minecraft/mods/.
