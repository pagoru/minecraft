Mini Dragon 1.0 - Minecraft 1.2.5
Author: pagoru

Hit a placed dragon egg with a golden hoe (left-click) and it hatches into
your own pet dragon, a bit taller than the player (about 2 blocks).

The dragon works like a tamed wolf:
- Follows you and teleports to you when it falls far behind.
- Right-click it (without food) to make it sit or stand up.
- Attacks whatever you hit and whatever hits you or it.
- Shoots small fireballs with flame particles (range 16 blocks) and bites
  with fire up close. Its fireballs never hurt you or other tamed pets and
  never set blocks on fire.
- Immune to fire and lava, no fall damage, 30 health.
- It doesn't heal by itself: right-click it with any food to heal it.

Works with Golden Fire Hoe and Dragon Egg (get the egg from the creative
inventory or with 8 obsidian around 1 eye of ender).

Single player. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put mini_dragon_125.zip in .minecraft/mods/.
Uses entity IDs 160 and 161.
