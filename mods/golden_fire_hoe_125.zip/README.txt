Golden Fire Hoe 1.0 - Minecraft 1.2.5
Author: pagoru

Right-click with a golden hoe to shoot a small fireball with flame particles.
It sets mobs and blocks on fire. Each shot costs 1 durability, like a sword hit
(32 shots per hoe). Right-clicking dirt/grass still tills it.
Uses the vanilla golden hoe and its normal recipe (also in the creative inventory).

Single player. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put golden_fire_hoe_125.zip in .minecraft/mods/.
