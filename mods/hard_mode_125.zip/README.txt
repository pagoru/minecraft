Hard Mode 1.0 - Minecraft 1.2.5
Author: pagoru
Created: 13/7/2013

Makes survival harder (singleplayer):
- Difficulty is locked to Hard.
- World hostile mob cap doubled (70 -> 140).
- Extra hostile mobs spawn 18-40 blocks around you at night and
  while you are in caves (zombies, skeletons, spiders, creepers,
  plus cave spiders underground), up to 30 mobs near you.
- Hostile mobs have +50% health, walk ~15-20% faster and deal +50%
  damage to you.
- 5% of creepers spawn charged.
- Loot (mobs killed by you): normal drops doubled, 50% chance
  (15% for animals, +10% per Looting level) of a random extra item
  (coal, arrows, food, iron/gold, redstone, lapis, XP bottles,
  ender pearls, saddles, diamonds, golden apples, records...),
  and endermen drop 1-3 extra ender pearls.
- Nothing extra spawns in creative mode.

All values are constants at the top of mod_HardMode.java.

Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
