Keep Inventory 1.0 - Minecraft 1.2.5
Author: pagoru

In creative, 1.2.5 fills the hotbar with stone, brick, dirt, etc. and sets
stacks to 1 every time you load a world. This mod restores the inventory
exactly as it was saved with the world (also after changing dimension).
Single player creative only. Survival is untouched.

Client only. Requires: Minecraft Forge + ModLoader for 1.2.5.
Install: put this zip in .minecraft/mods/.
